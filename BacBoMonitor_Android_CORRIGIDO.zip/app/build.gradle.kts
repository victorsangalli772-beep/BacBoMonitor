plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.stk.bacbomonitor"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.stk.bacbomonitor"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
