package com.stk.bacbomonitor

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.*

class MainActivity : Activity() {
    private val request = 9001
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,40,30,30)}
        box.addView(TextView(this).apply{
            text="🎯 BAC BO MONITOR\n\nLeia automaticamente o histórico da mesa pela captura de tela.\n\nSinal: 🟥 🟨 ou 🟦 🟨\nResultado: GREEN / RED por voz."
            textSize=19f
        })
        val overlay=Button(this).apply{text="1 — Permitir sobreposição"}
        val start=Button(this).apply{text="2 — Iniciar leitura da tela"}
        box.addView(overlay);box.addView(start);setContentView(box)
        overlay.setOnClickListener{startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName")))}
        start.setOnClickListener{
            val m=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(m.createScreenCaptureIntent(),request)
        }
    }
    override fun onActivityResult(rc:Int,result:Int,data:Intent?){
        super.onActivityResult(rc,result,data)
        if(rc==request && result==RESULT_OK && data!=null){
            startForegroundService(Intent(this,CaptureService::class.java).apply{
                putExtra("resultCode",result);putExtra("data",data)
            })
        }
    }
}
