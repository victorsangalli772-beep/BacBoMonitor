package com.stk.bacbomonitor

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.media.*
import android.media.projection.MediaProjectionManager
import android.os.*
import android.speech.tts.TextToSpeech
import java.util.*
import kotlin.math.min

class CaptureService: Service(){
    private var projection:MediaProjection?=null
    private var reader:ImageReader?=null
    private var tts:TextToSpeech?=null
    private var previous=""
    private var pending:Char?=null
    private val results=ArrayDeque<Char>()

    override fun onCreate(){
        super.onCreate()
        val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("monitor","Bac Bo Monitor",NotificationManager.IMPORTANCE_LOW))
        startForeground(1,Notification.Builder(this,"monitor")
            .setContentTitle("Bac Bo Monitor").setContentText("Analisando a tela…")
            .setSmallIcon(android.R.drawable.ic_menu_view).build())
        tts=TextToSpeech(this){}
    }

    override fun onStartCommand(i:Intent?,flags:Int,id:Int):Int{
        val code=i?.getIntExtra("resultCode",0)?:return START_NOT_STICKY
        val data=i.getParcelableExtra<Intent>("data")?:return START_NOT_STICKY
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=mgr.getMediaProjection(code,data)
        val dm=resources.displayMetrics
        reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,PixelFormat.RGBA_8888,2)
        projection!!.createVirtualDisplay("BacBo",dm.widthPixels,dm.heightPixels,dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null)
        reader!!.setOnImageAvailableListener({r->
            val image=r.acquireLatestImage()?:return@setOnImageAvailableListener
            try{readHistory(image)}finally{image.close()}
        },Handler(Looper.getMainLooper()))
        return START_STICKY
    }

    private fun readHistory(image:Image){
        val p=image.planes[0];val buf=p.buffer;val stride=p.rowStride;val pixel=p.pixelStride
        val w=image.width;val h=image.height
        // Região inicial aproximada. O projeto final deve ter calibração por arraste.
        val top=(h*.72).toInt();val bottom=(h*.91).toInt()
        val found=mutableListOf<Char>()
        fun rgb(x:Int,y:Int):IntArray{
            val pos=y*stride+x*pixel
            if(pos+2>=buf.capacity())return intArrayOf(0,0,0)
            return intArrayOf(buf.get(pos).toInt()and 255,buf.get(pos+1).toInt()and 255,buf.get(pos+2).toInt()and 255)
        }
        val step=(w/50).coerceAtLeast(10)
        for(x in (w*.03).toInt() until (w*.97).toInt() step step){
            var r=0;var g=0;var b=0;var n=0
            for(y in top..min(bottom,h-1) step 7){val c=rgb(x,y);r+=c[0];g+=c[1];b+=c[2];n++}
            if(n==0)continue;r/=n;g/=n;b/=n
            val c=when{
                b>r*1.18&&b>g*1.05&&b>100->'P'
                r>b*1.18&&r>g*1.05&&r>100->'B'
                r>150&&g>120&&b<120->'T'
                else->'-'
            }
            if(c!='-')found+=c
        }
        if(found.isEmpty())return
        val signature=found.joinToString("")
        if(signature==previous)return
        previous=signature
        val result=found.last()
        synchronized(results){
            if(results.isEmpty()||results.last()!=result)results.addLast(result)
            while(results.size>60)results.removeFirst()

            pending?.let{signal->
                val hit=(signal==result||result=='T')
                tts?.speak(if(hit)"GREEN!" else "RED!",TextToSpeech.QUEUE_FLUSH,null,"result")
                pending=null
            }

            // Estratégia heurística inicial. Não prevê nem garante o resultado.
            pending=if(results.count{it=='P'}<=results.count{it=='B'})'P' else 'B'
        }
    }

    override fun onBind(i:Intent?)=null
    override fun onDestroy(){reader?.close();projection?.stop();tts?.shutdown();super.onDestroy()}
}
