# BAC BO MONITOR — projeto corrigido

Este ZIP está preparado para compilação Android e inclui um workflow do GitHub Actions
que gera automaticamente `app-debug.apk`.

## Importante
- É um protótipo de leitura de tela.
- A área da mesa precisa ser calibrada para o site/aplicativo real.
- A detecção P/B/T é baseada em cores e pode precisar de ajustes.
- O sinal é estatístico/heurístico e NÃO garante acerto.
- Tie é tratado como resultado possível; não existe garantia de Tie.

## Gerar APK pelo navegador
1. Crie um repositório no GitHub.
2. Envie todos os arquivos deste ZIP.
3. Abra Actions > Build APK > Run workflow.
4. Quando terminar, abra a execução e baixe o artefato `BacBoMonitor-debug`.
